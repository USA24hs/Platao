"""Gera os icones PNG do PWA (Sistema de Deslocamento VTR)."""
from PIL import Image, ImageDraw

BG = (14, 90, 119, 255)       # #0e5a77
WHITE = (255, 255, 255, 255)

def base_canvas(S, full_bleed):
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    if full_bleed:
        d.rectangle([0, 0, S, S], fill=BG)
    else:
        d.rounded_rectangle([0, 0, S - 1, S - 1], radius=int(S * 0.22), fill=BG)
    return img, d

def draw_cross(d, S, scale):
    cx = cy = S / 2
    L = S * scale
    T = S * 0.20
    r = int(T * 0.28)
    d.rounded_rectangle([cx - L / 2, cy - T / 2, cx + L / 2, cy + T / 2], radius=r, fill=WHITE)
    d.rounded_rectangle([cx - T / 2, cy - L / 2, cx + T / 2, cy + L / 2], radius=r, fill=WHITE)

def make_icon(size, path, full_bleed=False, scale=0.60):
    S = size * 4
    img, d = base_canvas(S, full_bleed)
    draw_cross(d, S, scale)
    img = img.resize((size, size), Image.LANCZOS)
    img.save(path)
    print("ok", path, img.size)

make_icon(192, "download/icon-192.png")
make_icon(512, "download/icon-512.png")
make_icon(512, "download/icon-512-maskable.png", full_bleed=True, scale=0.50)
make_icon(180, "download/apple-touch-icon.png", full_bleed=True)
